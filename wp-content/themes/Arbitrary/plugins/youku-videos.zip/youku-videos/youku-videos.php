<?php
/*
Plugin Name: Youku Videos
Plugin URI: http://mufeng.me/youku-videos.html
Description: 优酷视频展示 (Youku Videos For Arbitrary 1.40)
Version: 1.0.7
Author: Mufeng
Author URI: http://mufeng.me
*/

define('VERSION', '1.0.7');
require_once(dirname(__FILE__).'/function.php');

?>